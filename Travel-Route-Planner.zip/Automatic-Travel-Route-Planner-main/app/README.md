#### In order to run this application, the required environment and dependencies must be installed first. 

# Installation
## Step 1: Install NodeJS
Download NodeJS [here](https://nodejs.org/en/).
## Step 2: Install Dependencies
Open the current directory (`.../app`) in the terminal. Run `npm install`.
## Step 3: Run Web App
While still in this directory, run `npm start`.

#### After following the steps above, the local server should be already active and running the application.
